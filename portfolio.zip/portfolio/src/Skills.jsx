import React from 'react';

function Skills() {
  const skills = [
    {
      category: 'Programming',
      details: 'Python, Java, C++',
      icon: '💻',
    },
    {
      category: 'Frontend Development',
      details: 'HTML, CSS, JavaScript',
      icon: '🌐',
    },
    {
      category: 'Core Concepts',
      details: 'Data Structures and Algorithms',
      icon: '📚',
    },
    {
      category: 'Tools',
      details: 'VS Code, Canva, GitHub,Power-BI,Tableau',
      icon: '🛠️',
    },
  ];

  return (
    <div style={styles.container}>
      <h1 style={styles.heading}>My Skills</h1>
      <div style={styles.skillsGrid}>
        {skills.map((skill, index) => (
          <div key={index} style={styles.skillCard}>
            <div style={styles.icon}>{skill.icon}</div>
            <h2 style={styles.skillCategory}>{skill.category}</h2>
            <p style={styles.skillDetails}>{skill.details}</p>
          </div>
        ))}
      </div>
    </div>
  );
}

const styles = {
  container: {
    padding: '20px',
    maxWidth: '1200px',
    margin: '0 auto',
    textAlign: 'center',
    fontFamily: '"Arial", sans-serif',
    color: '#333',
  },
  heading: {
    fontSize: '2.5em',
    marginBottom: '30px',
    color: '#007BFF',
  },
  skillsGrid: {
    display: 'grid',
    gridTemplateColumns: 'repeat(auto-fit, minmax(250px, 1fr))',
    gap: '20px',
  },
  skillCard: {
    backgroundColor: '#f9f9f9',
    border: '1px solid #ddd',
    borderRadius: '10px',
    padding: '20px',
    boxShadow: '0 4px 8px rgba(0, 0, 0, 0.1)',
    transition: 'transform 0.3s ease',
  },
  skillCardHover: {
    transform: 'scale(1.05)',
  },
  icon: {
    fontSize: '2.5em',
    marginBottom: '10px',
  },
  skillCategory: {
    fontSize: '1.5em',
    marginBottom: '10px',
    color: '#007BFF',
  },
  skillDetails: {
    fontSize: '1em',
    color: '#555',
  },
};

export default Skills;
