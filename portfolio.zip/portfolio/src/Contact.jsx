import React from 'react';

function Contact() {
  return (
    <div style={styles.page}>
      <h1 style={styles.heading}>Contact Me</h1>
      <div style={styles.contactInfo}>
        <p style={styles.infoText}>
          <strong>Email:</strong> <a href="mailto:malini.a2023ai-ds@sece.ac.in" style={styles.link}>malini.a2023ai-ds@sece.ac.in</a>
        </p>
        <p style={styles.infoText}>
          <strong>Phone:</strong> <a href="tel:+918122552304" style={styles.link}>8122552304</a>
        </p>
        <p style={styles.infoText}>
          <strong>LinkedIn:</strong> <a href="https://www.linkedin.com/in/malini-a-ai-ds-665578340/ " target="_blank" rel="noopener noreferrer" style={styles.link}>LinkedIn Profile</a>
        </p>
      </div>
      <div style={styles.footer}>
        <p>Feel free to reach out for collaborations or inquiries!</p>
      </div>
    </div>
  );
}

const styles = {
  page: {
    fontFamily: '"Arial", sans-serif',
    color: '#333',
    backgroundColor:'#f4c5e0',
    padding: '30px',
    textAlign: 'center',
  },
  heading: {
    fontSize: '2.5em',
    color: '#007BFF',
    marginBottom: '30px',
  },
  contactInfo: {
    display: 'flex',
    flexDirection: 'column',
    alignItems: 'center',
    marginTop: '20px',
  },
  infoText: {
    fontSize: '1.2em',
    margin: '10px 0',
    color: '#555',
  },
  link: {
    color: '#007BFF',
    textDecoration: 'none',
    fontWeight: 'bold',
  },
  footer: {
    marginTop: '30px',
    fontSize: '1.1em',
    color: '#777',
  },
};

export default Contact;
