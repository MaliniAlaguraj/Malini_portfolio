import React from 'react';

function Home() {
  return (
    <div style={styles.container}>
      <header style={styles.header}>
        <h1 style={styles.heading}>Welcome to My Portfolio</h1>
        <p style={styles.subheading}>Hi, I'm <span style={styles.highlight}>Malini</span>, an aspiring AI & Data Science professional.</p>
      </header>
      <section style={styles.aboutSection}>
        <p style={styles.paragraph}>
          I am a passionate learner and problem solver specializing in Artificial Intelligence and Data Science. I enjoy working on innovative projects that combine technology and creativity to deliver impactful solutions.
        </p>
      </section>
      <section style={styles.experienceSection}>
        <h2 style={styles.sectionHeading}>What I Do</h2>
        <ul style={styles.list}>
          <li>Develop intuitive and dynamic web applications using modern frameworks.</li>
          <li>Analyze data to uncover insights and build predictive models.</li>
          <li>Create user-friendly interfaces and deliver engaging user experiences.</li>
          <li>Work on innovative projects to integrate AI and machine learning solutions.</li>
        </ul>
      </section>
      <section style={styles.contactSection}>
        <h2 style={styles.sectionHeading}>Get in Touch</h2>
        <p style={styles.paragraph}>
          Have an exciting project or collaboration in mind? Let’s connect and create something amazing together!
        </p>
        <a href="/contact" style={styles.contactButton}>Contact Me</a>
      </section>
    </div>
  );
}

const styles = {
  container: {
    padding: '20px',
    maxWidth: '900px',
    margin: '0 auto',
    fontFamily: '"Arial", sans-serif',
    color: '#333',
    lineHeight: '1.6',
  },
  header: {
    textAlign: 'center',
    marginBottom: '30px',
  },
  heading: {
    fontSize: '2.5em',
    margin: '10px 0',
    color: '#444',
  },
  subheading: {
    fontSize: '1.2em',
    color: '#666',
  },
  highlight: {
    color: '#007BFF',
    fontWeight: 'bold',
  },
  aboutSection: {
    marginBottom: '30px',
  },
  experienceSection: {
    marginBottom: '30px',
  },
  sectionHeading: {
    fontSize: '1.8em',
    marginBottom: '10px',
    color: '#007BFF',
  },
  paragraph: {
    fontSize: '1em',
    marginBottom: '10px',
  },
  list: {
    listStyleType: 'disc',
    paddingLeft: '20px',
  },
  contactSection: {
    textAlign: 'center',
    backgroundColor: '#f4f4f4',
    padding: '20px',
    borderRadius: '10px',
  },
  contactButton: {
    display: 'inline-block',
    marginTop: '10px',
    padding: '10px 20px',
    backgroundColor: 'green',
    color: '#fff',
    textDecoration: 'none',
    borderRadius: '5px',
    fontSize: '1em',
  },
};

export default Home;
