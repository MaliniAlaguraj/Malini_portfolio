import React from 'react';

function Projects() {
  const projects = [
    {
      name: 'Email Spam Detection',
      description: 'A system using advanced algorithms to detect and filter out spam emails, improving email management.',
      
    },
    {
      name: 'Hotel Booking System',
      description: 'A web-based system for hotel booking with real-time availability, room selection, and booking management.',
      },
    {
      name: 'Text to Speech (Python)',
      description: 'A Python application that converts text to speech using TTS (Text-to-Speech) technology.',
      },
    {
      name: 'Tourism Demand Forecasting',
      description: 'A data science project that predicts tourism demand using machine learning models and historical data.',
      },
  ];

  return (
    <div style={styles.page}>
      <h1 style={styles.heading}>My Projects</h1>
      <div style={styles.projectsGrid}>
        {projects.map((project, index) => (
          <div key={index} style={styles.projectCard}>
            <h2 style={styles.projectTitle}>{project.name}</h2>
            <p style={styles.projectDescription}>{project.description}</p>
            
          </div>
        ))}
      </div>
    </div>
  );
}

const styles = {
  page: {
    fontFamily: '"Arial", sans-serif',
    color: '#333',
    padding: '30px',
    backgroundColor:'#f4c5e0',
    textAlign: 'center',
  },
  heading: {
    fontSize: '2.5em',
    marginBottom: '40px',
    color: '#007BFF',
  },
  projectsGrid: {
    display: 'grid',
    gridTemplateColumns: 'repeat(auto-fill, minmax(280px, 1fr))',
    gap: '20px',
    marginTop: '30px',
  },
  projectCard: {
    backgroundColor: '#fff',
    padding: '20px',
    borderRadius: '10px',
    boxShadow: '0 4px 10px rgba(0, 0, 0, 0.1)',
    transition: 'transform 0.3s ease, box-shadow 0.3s ease',
    cursor: 'pointer',
  },
  projectCardHover: {
    transform: 'scale(1.05)',
    boxShadow: '0 6px 15px rgba(0, 0, 0, 0.2)',
  },
  projectTitle: {
    fontSize: '1.8em',
    color: '#333',
    marginBottom: '10px',
  },
  projectDescription: {
    fontSize: '1.1em',
    color: '#555',
    marginBottom: '20px',
  },
  projectLink: {
    fontSize: '1.1em',
    color: '#007BFF',
    textDecoration: 'none',
    fontWeight: 'bold',
  },
};

export default Projects;
