import React from 'react';

function About() {
  return (
    <div style={styles.container}>
      <header style={styles.header}>
        <h1 style={styles.heading}>About Me</h1>
        <p style={styles.subheading}>
          Hi, I'm <span style={styles.highlight}>Malini</span>, an AI & Data Science enthusiast, constantly exploring the possibilities of technology to solve real-world problems.
        </p>
      </header>

      <section style={styles.section}>
        <h2 style={styles.sectionHeading}>Who Am I?</h2>
        <p style={styles.paragraph}>
          I am currently pursuing my B.Tech in Artificial Intelligence and Data Science at Sri Eshwar College of Engineering (2023–2027). My journey has been fueled by curiosity, innovation, and a passion for learning cutting-edge technologies.
        </p>
      </section>

      <section style={styles.section}>
        <h2 style={styles.sectionHeading}>Certifications</h2>
        <ul style={styles.list}>
          <li>
            <strong> C</strong> – Great Learning (2024)
          </li>
          <li>
            <strong> C++</strong> – Great Learning (2024)
          </li>
          <li>
            <strong>Java Programming</strong> – Udemy (2024)
          </li>
          <li>
            <strong>Numpy and pandas</strong> – Kaggle(2024)
          </li>
          <li>
            <strong>Data Science</strong> – Great Learning (2024)
          </li>
        </ul>
      </section>

      <section style={styles.section}>
        <h2 style={styles.sectionHeading}>Achievements</h2>
        <ul style={styles.list}>
          <li>
            Secured <strong>2nd Position</strong> in CODEATHON – a prestigious coding competition showcasing problem-solving and programming skills.
          </li>
        </ul>
      </section>

      <section style={styles.section}>
        <h2 style={styles.sectionHeading}>My Vision</h2>
        <p style={styles.paragraph}>
          My goal is to leverage my skills and knowledge to contribute to projects that make a meaningful impact. Whether it's developing innovative AI solutions, analyzing data for better decision-making, or creating seamless user experiences, I am committed to achieving excellence.
        </p>
      </section>
    </div>
  );
}

const styles = {
  container: {
    padding: '20px',
    maxWidth: '900px',
    margin: '0 auto',
    fontFamily: '"Arial", sans-serif',
    color: '#333',
    lineHeight: '1.6',
  },
  header: {
    textAlign: 'center',
    marginBottom: '30px',
  },
  heading: {
    fontSize: '2.5em',
    margin: '10px 0',
    color: '#444',
  },
  subheading: {
    fontSize: '1.2em',
    color: '#666',
  },
  highlight: {
    color: '#007BFF',
    fontWeight: 'bold',
  },
  section: {
    marginBottom: '30px',
  },
  sectionHeading: {
    fontSize: '1.8em',
    marginBottom: '10px',
    color: '#007BFF',
  },
  paragraph: {
    fontSize: '1em',
    marginBottom: '10px',
  },
  list: {
    listStyleType: 'disc',
    paddingLeft: '20px',
  },
};

export default About;
